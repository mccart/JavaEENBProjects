Guidelines for completing the labs of WJ-3101-EE5, WJ-3102-EE5, WJ-3103-EE5 or WJ-3104_EE5
============================================================================================

1) This downloadadble file contains the following:
  a) WJ-310_A_labfiles.zip - Lab files
  b) WJ-310-A-LOG.pdf - Lab Operations Guide (LOG)
  c) ToolReference.pdf - NetBeans Integrated Development Environment (IDE) tool reference guide

2) WJ-310_A_labfiles.zip contains all the files needed to perform the exercises of all the modules of: 
   WJ-3101-EE5 - Introduction to the Java™ EE Platform, 
   WJ-3102-EE5 - Developing Components for the Java™ EE Platform 
   WJ-3103-EE5 - Implementing Persistence, Transactions and Messaging in a Java EE™ Application and 
   WJ-3104-EE5 - Implementing Java EE™ Web Services and Security 

3) The LOG contains all the information needed to set up your system for doing the exercises. Read and follow 
   the setup instructions given in the LOG before you start your exercises

4) The tool reference guide contains instructions on how to work with NetBeans IDE. You can refer it while doing 
   the exercises. Reference to specific pages of the guide has been made in the workbook wherever needed.

5) The instructions on how to complete the exercises are given in the workbook in pdf format. The workbook can 
   be opened and saved on click of a button at the summary page of each module of every course.

6) The lab files can be downloaded from a link available at the summary page of each module of every course.
   You need to download the lab files only once for completing the exercises of any module out of all the 
   four courses (WJ-3101-EE5, WJ-3102-EE5, WJ-3103-EE5 or WJ-3104-EE5).
