import java.io.Serializable;
import javax.persistence.*;

@Entity @Table(name = "TABLE1")
public class MyEntity implements Serializable {
    
    @Id @Column(name = "ID") private int id;
    @Column(name = "MSG") private String message;
    
    protected MyEntity() { }
    public MyEntity(int id, String message) {
        this.id = id;
        this.message = message;
    }
    
    public int getId() { return id; }
    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }
}