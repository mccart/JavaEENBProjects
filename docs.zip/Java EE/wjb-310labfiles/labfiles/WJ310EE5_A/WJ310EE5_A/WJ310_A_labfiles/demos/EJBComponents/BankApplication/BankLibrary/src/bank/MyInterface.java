package bank;

/**
 * This is the business interface for MySession enterprise bean.
 */
public interface MyInterface {
    void myMethod();
    String getString();
}
