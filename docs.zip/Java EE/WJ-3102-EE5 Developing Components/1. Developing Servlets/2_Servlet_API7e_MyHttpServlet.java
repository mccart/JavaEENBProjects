import java.net.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class MyHttpServlet extends HttpServlet {
	public void doGet (HttpServletRequest request, HttpServletResponse response) {
		processRequest (request, response);
		}

public void doPost (HttpServletRequest request, HttpServletResponse response) {
	processRequest (request, response);
	}

public void processRequest(HttpServletRequest request, HttpServletResponse response) {
	// Process request and generate response
	}
}