import javax.persistence.*;
import javax.ejb.*;

@Remote @Stateless
public class BrokerModelImpl implements BrokerModel {

    @PersistenceContext private EntityManager em;
    public Stock getStock(String symbol) throws BrokerException {
        Stock stock = em.find(Stock.class, symbol);
        if(stock != null) {
            return stock;
        } else {
            throw new BrokerException("Stock : " + symbol +
                    " not found");
        }
    }
    
    public void addStock(Stock stock) throws BrokerException {
        try {
            em.persist(stock);
        }catch(EntityExistsException exe) {
            throw new BrokerException("Duplicate Stock : " +
                    stock.getSymbol());
        }
    }
    
    public void updateStock(Stock stock) throws BrokerException {
        Stock s = em.find(Stock.class, stock.getSymbol());
        if(s == null) {
            throw new BrokerException("Stock : " + stock.getSymbol() + " not found");
        } else {
            em.merge(stock);
        }
    }
    
    public void deleteStock(Stock stock) throws BrokerException {
        String id = stock.getSymbol();
        stock = em.find(Stock.class, id);
        if(stock == null) {
            throw new BrokerException("Stock : " +
                    stock.getSymbol() +" not found");
        } else {
            em.remove(stock);
        }
    }
}

